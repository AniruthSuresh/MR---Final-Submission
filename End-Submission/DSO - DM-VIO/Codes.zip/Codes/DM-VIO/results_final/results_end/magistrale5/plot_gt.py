import numpy as np
import matplotlib.pyplot as plt

def load_ground_truth(filename):
    """
    Load ground truth trajectory from TUM format file.
    Parameters:
        filename: Path to the TUM format ground truth file.
    Returns:
        positions: nx3 numpy array of (x, y, z) positions.
    """
    try:
        data = np.loadtxt(filename)
        # Extract positions (x, y, z)
        positions = data[:, 1:4]
        return positions
    except Exception as e:
        print(f"Error loading {filename}: {e}")
        return None

def plot_ground_truth(ground_truth):
    """
    Plot the ground truth trajectory in 3D.
    Parameters:
        ground_truth: nx3 numpy array of (x, y, z) positions.
    """
    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')
    ax.plot(ground_truth[:, 0], ground_truth[:, 1], ground_truth[:, 2], label='Ground Truth', color='blue')
    
    # Set labels
    ax.set_xlabel('X (m)')
    ax.set_ylabel('Y (m)')
    ax.set_zlabel('Z (m)')
    ax.set_title('Ground Truth Trajectory')
    
    # Add legend and grid
    ax.legend()
    ax.grid(True)
    plt.show()

# Path to the ground truth file
ground_truth_file = './gt.txt'

# Load and plot ground truth trajectory
ground_truth = load_ground_truth(ground_truth_file)
if ground_truth is not None:
    plot_ground_truth(ground_truth)
