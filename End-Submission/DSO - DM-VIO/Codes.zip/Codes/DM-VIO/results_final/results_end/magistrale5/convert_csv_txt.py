import csv

# Specify input CSV file and output TXT file paths
csv_file_path = './gt_imu.csv'
txt_file_path = './gt.txt'

# Open the CSV file and read its content
with open(csv_file_path, 'r') as csv_file:
    csv_reader = csv.reader(csv_file)
    
    # Open the TXT file to write content
    with open(txt_file_path, 'w') as txt_file:
        for row in csv_reader:
            # Join the CSV row with a tab or space, and write to the TXT file
            txt_file.write('\t'.join(row) + '\n')

print(f"CSV file '{csv_file_path}' successfully converted to TXT file '{txt_file_path}'.")
