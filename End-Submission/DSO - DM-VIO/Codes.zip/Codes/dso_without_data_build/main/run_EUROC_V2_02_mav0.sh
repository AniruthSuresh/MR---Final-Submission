../build/bin/dso_dataset \
		files=../data/V2_02_medium/mav0/cam0/data \
		calib=../data/V2_02_medium/mav0/EUROC.txt \
		preset=0 \
		mode=1