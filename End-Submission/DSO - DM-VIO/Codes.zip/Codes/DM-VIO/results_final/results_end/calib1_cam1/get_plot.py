import numpy as np
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.colors import Normalize

def plot_trajectory_with_error(estimated_traj, reference_traj, errors=None):
    """
    Plot trajectory with color-coded error visualization
    
    Parameters:
    estimated_traj: nx2 numpy array with (x,y) coordinates of estimated trajectory
    reference_traj: nx2 numpy array with (x,y) coordinates of reference trajectory
    errors: n-length numpy array of error values for color coding
    """
    # Create figure
    plt.figure(figsize=(10, 8))
    
    # Plot reference trajectory as dashed line
    plt.plot(reference_traj[:, 0], reference_traj[:, 1], '--', color='gray', 
             label='reference', alpha=0.5)
    
    # Create line segments for color coding
    points = estimated_traj.reshape(-1, 1, 2)
    segments = np.concatenate([points[:-1], points[1:]], axis=1)
    
    # Create color-coded line collection
    if errors is None:
        # If no errors provided, use distance from reference as error
        errors = np.sqrt(np.sum((estimated_traj - reference_traj)**2, axis=1))
    
    norm = Normalize(vmin=errors.min(), vmax=errors.max())
    lc = LineCollection(segments, cmap='plasma', norm=norm)
    lc.set_array(errors[:-1])
    
    # Add colored trajectory to plot
    plt.gca().add_collection(lc)
    
    # Add colorbar
    plt.colorbar(lc, label='Error (m)')
    
    # Set labels and title
    plt.xlabel('x (m)')
    plt.ylabel('y (m)')
    plt.title('Error mapped onto trajectory')
    
    # Set equal aspect ratio and grid
    plt.axis('equal')
    plt.grid(True)
    
    # Add legend
    plt.legend()
    
    return plt.gca()

# def load_tum_trajectory(filename):
#     """Load trajectory from TUM format file"""
#     data = np.loadtxt(filename)
#     # Extract positions (x,y,z)
#     positions = data[:, 1:4]  # Columns 1,2,3 are x,y,z
#     return positions

def load_tum_trajectory(filename):
    """
    Load trajectory from TUM format file and handle NaN values
    Returns timestamps and positions
    """
    try:
        data = np.loadtxt(filename)
        # Remove rows with NaN values
        valid_rows = ~np.isnan(data).any(axis=1)
        clean_data = data[valid_rows]
        # Extract timestamps and positions
        timestamps = clean_data[:, 0]  # First column is timestamp
        positions = clean_data[:, 1:4]  # Columns 1,2,3 are x,y,z
        return positions
    except Exception as e:
        print(f"Error loading {filename}: {e}")
        return None

# Load trajectories
estimated_traj = load_tum_trajectory('./result.txt')
reference_traj = load_tum_trajectory('./matched_results_gt.txt')

# Plot 2D trajectory (x-y plane)
plot_trajectory_with_error(estimated_traj[:, :2][:500], reference_traj[:, :2][:500])
plt.show()