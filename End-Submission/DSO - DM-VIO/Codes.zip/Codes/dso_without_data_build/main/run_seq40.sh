../build/bin/dso_dataset \
		files=../data/sequence_40/images.zip \
		calib=../data/sequence_40/camera.txt \
		gamma=../data/sequence_40/pcalib.txt \
		vignette=../data/sequence_40/vignette.png \
		preset=0 \
		mode=0