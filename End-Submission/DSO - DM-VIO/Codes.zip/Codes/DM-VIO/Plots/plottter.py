import matplotlib.pyplot as plt
import matplotlib.image as mpimg

# Load the images
img1 = mpimg.imread("/home/aniruth/Plots/cam5.jpeg")
img2 = mpimg.imread('/home/aniruth/Plots/cam5_both.png')

# Create a 1x2 subplot
fig, axes = plt.subplots(1, 2, figsize=(10, 5))  # 1 row, 2 columns

# Display the first image
axes[0].imshow(img1)
axes[0].axis('off')  # Hide the axis
axes[0].set_title("Original Trajectory")  # Title for the first subplot

# Display the second image
axes[1].imshow(img2)
axes[1].axis('off')  # Hide the axis
axes[1].set_title("Estimated Trajectory of DSO and DM - VIO")  # Title for the second subplot

# Apply tight layout to adjust subplots and avoid overlap
plt.tight_layout()

# Save the figure
plt.savefig("cam5_fin.png")

# Show the plot
plt.show()
