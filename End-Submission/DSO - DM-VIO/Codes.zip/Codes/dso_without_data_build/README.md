# MR Final-Submission DSO


### 1 Related Papers
* **Direct Sparse Odometry**, *J. Engel, V. Koltun, D. Cremers*, In arXiv:1607.02565, 2016
* **A Photometrically Calibrated Benchmark For Monocular Visual Odometry**, *J. Engel, V. Usenko, D. Cremers*, In arXiv:1607.02555, 2016

### 2 Installation



		sudo apt-get install libsuitesparse-dev libeigen3-dev libboost-all-dev

		sudo apt-get install libopencv-dev

##### To get the 3d visualization of the entire constructed scene we used pangolin v0.6.
	https://github.com/stevenlovegrove/Pangolin/tree/v0.6


##### To read the dataset which is present in zip format :

	sudo apt-get install zlib1g-dev
	cd dso/thirdparty
	tar -zxvf libzip-1.1.1.tar.gz
	cd libzip-1.1.1/
	./configure
	make
	sudo make install
	sudo cp lib/zipconf.h /usr/local/include/zipconf.h   


##### Building DSO

		cd dso
		mkdir build
		cd build
		cmake ..
		make -j4


If the build process is sucessfull it will build a binary `dso_dataset`, to run DSO on datasets. 





### 3 Dataset Format.

We have used 2 datasets:
1. http://robotics.ethz.ch/~asl-datasets/ijrr_euroc_mav_dataset/vicon_room2/V2_02_medium/ - This is the EUROC_V2-02-medium-mav0 dataset

2. https://cvg.cit.tum.de/data/datasets/mono-dataset?redirect=1 - This is for the sequence_14 and sequence_40

- `files=XXX` where XXX is either a folder or .zip archive containing images. They are sorted *alphabetically*. for .zip to work, need to comiple with ziplib support.

- `gamma=XXX` where XXX is a gamma calibration file, containing a single row with 256 values, mapping [0..255] to the respective irradiance value, i.e. containing the *discretized inverse response function*. See TUM monoVO dataset for an example.

- `vignette=XXX` where XXX is a monochrome 16bit or 8bit image containing the vignette as pixelwise attenuation factors. See TUM monoVO dataset for an example.

- `calib=XXX` where XXX is a geometric camera calibration file. See below.


### 4 Usage

	cd main

	./run_seq14.sh				## for running sequence 14

	./run_seq40.sh				## for running sequence 40

	./run_EUROC_V2_02_mav0.sh	## for running EUROC_V2_02_mav0





