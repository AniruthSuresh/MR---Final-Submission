import numpy as np

# File paths
results_file = 'result_dso.txt'
matched_results_file = 'matched_results_gt_dso.txt'

# Function to compute RMSE
def compute_rmse(predicted, actual):
    predicted = np.array(predicted, dtype=float)
    actual = np.array(actual, dtype=float)
    return np.sqrt(np.mean((predicted - actual) ** 2))

# Load values from results.txt
results_data = []
with open(results_file, 'r') as results:
    for line in results:
        parts = line.split()
        values = list(map(float, parts[1:]))  # Skip timestamp, load values
        results_data.append(values)

# Load values from matched_results.txt
matched_results_data = []
with open(matched_results_file, 'r') as matched:
    for line in matched:
        parts = line.split()
        values = list(map(float, parts[1:]))  # Skip timestamp, load values
        matched_results_data.append(values)

# Ensure data alignment
if len(results_data) != len(matched_results_data):
    raise ValueError("Mismatch in row counts between files.")

# Compute RMSE for each row
rmses = []
for res_values, match_values in zip(results_data, matched_results_data):
    rmse = compute_rmse(res_values, match_values)
    rmses.append(rmse)

# Overall RMSE
overall_rmse = np.mean(rmses)

print(f"RMSE for each row: {rmses}")
print(f"Overall RMSE: {overall_rmse}")
