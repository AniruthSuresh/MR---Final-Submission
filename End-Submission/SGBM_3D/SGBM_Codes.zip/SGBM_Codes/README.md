# MR Mid-Submission - SGBM


## 1 Installation


		conda create --name myenv
        conda activate myenv
        conda install numpy opencv matplotlib



## 2 Usage

	cd src

    python3 sgbm.py           # to run sbgm 
    python3 sgbm_plotter.py   # to generate the accuracy plot
    python3 benchmark.py      # to benchmark SGM , SGBM , OpenCV
