../build/bin/dso_dataset \
		files=../data/sequence_14/images.zip \
		calib=../data/sequence_14/camera.txt \
		gamma=../data/sequence_14/pcalib.txt \
		vignette=../data/sequence_14/vignette.png \
		preset=0 \
		mode=0