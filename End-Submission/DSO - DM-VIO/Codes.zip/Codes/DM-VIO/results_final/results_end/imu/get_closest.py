import numpy as np

# File paths
results_file = 'result_dso_imu.txt'
gt_file = 'gt.txt'
output_file = 'matched_results_gt_dso.txt'

# Function to convert timestamps from gt.txt to seconds for comparison
def timestamp_to_seconds(ns_timestamp):
    return float(ns_timestamp) / 1e9

# Read gt.txt into a list of tuples (timestamp in seconds, rest of the line)
gt_data = []
with open(gt_file, 'r') as gt:
    for line in gt:
        parts = line.split()
        timestamp_sec = timestamp_to_seconds(parts[0])
        values = parts[1:]
        gt_data.append((timestamp_sec, values))

# Read results.txt into a list of tuples (timestamp in seconds, rest of the line)
results_data = []
with open(results_file, 'r') as results:
    for line in results:
        parts = line.split()
        timestamp_sec = float(parts[0])
        values = parts[1:]
        results_data.append((timestamp_sec, values))

# Match each timestamp in results to the closest timestamp in gt
matched_data = []
for result_timestamp, result_values in results_data:
    # Find the closest timestamp in gt using numpy
    gt_timestamps = np.array([item[0] for item in gt_data])
    closest_idx = np.argmin(np.abs(gt_timestamps - result_timestamp))
    closest_gt_timestamp, closest_gt_values = gt_data[closest_idx]
    matched_data.append((result_timestamp, result_values, closest_gt_timestamp, closest_gt_values))

# Write matched data to a new file
with open(output_file, 'w') as out_file:
    for result_timestamp, result_values, closest_gt_timestamp, closest_gt_values in matched_data:
        out_file.write(f"{closest_gt_timestamp} {' '.join(closest_gt_values)}\n")

print(f"Matched data saved to '{output_file}'")
