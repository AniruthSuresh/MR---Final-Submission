import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from transforms3d.quaternions import quat2mat

class CameraVisualizer:

    def __init__(self):
        self.fig = plt.figure(figsize=(15, 10))
        self.ax = self.fig.add_subplot(111, projection='3d')
        
    def read_trajectory(self, filename):
        """
        Just a helper function to read the text file as 
        [x , y , z , qx , qy , qz , qw]
        """

        timestamps = []
        positions = []
        quaternions = []
        
        with open(filename, 'r') as f:
            for line in f:
                data = line.strip().split()
                if len(data) == 8:
                    timestamps.append(float(data[0]))
                    positions.append([float(data[1]), float(data[2]), float(data[3])])
                    quaternions.append([float(data[4]), float(data[5]), 
                                     float(data[6]), float(data[7])])
        
        return np.array(timestamps), np.array(positions), np.array(quaternions)


    def plot_camera_frame(self, position, quaternion, scale=0.5):
        """
        This function plots the orientation of the camera
        """
        R = quat2mat([quaternion[3], quaternion[0], quaternion[1], quaternion[2]])
        axes = np.array([[scale,0,0], [0,scale,0], [0,0,scale]])
        transformed_axes = np.dot(R, axes.T).T + position
        
        colors = ['r', 'g', 'b']
        for i in range(3):
            self.ax.plot([position[0], transformed_axes[i,0]],
                        [position[1], transformed_axes[i,1]],
                        [position[2], transformed_axes[i,2]], 
                        color=colors[i], linewidth=2)


    def create_static_plot(self, filename, save_path=None, show_frames_interval=500):
        """
        This function creates the static plot - NO GIF
        """
        timestamps, positions, quaternions = self.read_trajectory(filename)
        
        self.ax.plot(positions[:,0], positions[:,1], positions[:,2], 'k-', label='Camera Path')
        
        for i in range(0, len(positions), show_frames_interval):
            self.plot_camera_frame(positions[i], quaternions[i])
        
        self.ax.set_xlabel('X (m)')
        self.ax.set_ylabel('Y (m)')
        self.ax.set_zlabel('Z (m)')
        # self.ax.set_title('Camera Trajectory with Orientation Frames')
        
        self.set_equal_aspects()
        
        if save_path:
            plt.savefig(save_path, bbox_inches='tight')  # Removes extra white space
            print(f"Plot saved to {save_path}")
        else:
            plt.show()

    def set_equal_aspects(self):
        """
        Just a helper to set and limit it !
        """
        limits = np.array([
            self.ax.get_xlim3d(),
            self.ax.get_ylim3d(),
            self.ax.get_zlim3d(),
        ])
        
        center = np.mean(limits, axis=1)
        radius = 0.5 * np.max(np.abs(limits[:, 1] - limits[:, 0]))
        
        self.ax.set_xlim3d([center[0] - radius, center[0] + radius])
        self.ax.set_ylim3d([center[1] - radius, center[1] + radius])
        self.ax.set_zlim3d([center[2] - radius, center[2] + radius])


def main():

    # result_file_path = "../results/result_seq_14.txt"
    # plot_save_path = "../plots/traj_seq_14"

    # set scale = 1 for this 
    result_file_path = "./result_dso_magistrale5.txt"
    plot_save_path = "./magistrale5_dso"


    # result_file_path = "../results/result_EUROC_V2-02-medium-mav0.txt"
    # plot_save_path = "../plots/traj_EUROC.png"

    visualizer = CameraVisualizer()
    visualizer.create_static_plot(result_file_path, save_path=plot_save_path, show_frames_interval=50)
    

if __name__ == "__main__":
    main()
