import numpy as np
import matplotlib.pyplot as plt

def load_tum_trajectory(filename):
    """
    Load trajectory from TUM format file and handle NaN values.
    Returns timestamps and positions.
    """
    try:
        data = np.loadtxt(filename)
        # Remove rows with NaN values
        valid_rows = ~np.isnan(data).any(axis=1)
        clean_data = data[valid_rows]
        # Extract positions
        positions = clean_data[:, 1:4]  # Columns 1,2,3 are x,y,z
        return positions
    except Exception as e:
        print(f"Error loading {filename}: {e}")
        return None

def plot_trajectories(trajectory_1, trajectory_2, labels=('Trajectory 1', 'Trajectory 2')):
    """
    Plot two trajectories on the same plot for comparison.
    
    Parameters:
    trajectory_1: nx2 numpy array with (x,y) coordinates of first trajectory.
    trajectory_2: nx2 numpy array with (x,y) coordinates of second trajectory.
    labels: tuple of strings for the labels of the two trajectories.
    """
    plt.figure(figsize=(10, 8))
    
    # Plot the first trajectory
    plt.plot(trajectory_1[:, 0], trajectory_1[:, 1], label=labels[0], color='blue')
    
    # Plot the second trajectory
    plt.plot(trajectory_2[:, 0], trajectory_2[:, 1], label=labels[1], color='orange')
    
    # Set labels and title
    plt.xlabel('x (m)')
    plt.ylabel('y (m)')
    plt.title('Comparison of Trajectories')
    
    # Set equal aspect ratio and grid
    plt.axis('equal')
    plt.grid(True)
    
    # Add legend
    plt.legend()
    
    plt.show()

# Load trajectories
dso_traj = load_tum_trajectory('./result_dso.txt')  # Replace with DSO results file path
dmvio_traj = load_tum_trajectory('./result.txt')  # Replace with DVMIO results file path

# Plot 2D trajectories (x-y plane)
plot_trajectories(dso_traj[:, :2], dmvio_traj[:, :2], labels=('DSO', 'DVMIO'))
